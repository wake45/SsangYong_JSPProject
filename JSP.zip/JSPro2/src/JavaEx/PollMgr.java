package JavaEx;

import java.sql.*;
import java.util.Vector;

public class PollMgr {

	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "6896";

	public PollMgr() {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public Vector<PollListBean> getAllList() {
		PreparedStatement pstmt = null;
		String sql = null;
		Connection con = null;
		ResultSet rs = null;
		Vector<PollListBean> vlist = new Vector<PollListBean>();
		try {
			con = DriverManager.getConnection(url, user, pass);
			sql = "select * from tblPollList order by num desc";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				PollListBean plBean = new PollListBean();
				plBean.setNum(rs.getInt("num"));
				plBean.setQuestion(rs.getString("question"));
				plBean.setSdate(rs.getString("sdate"));
				plBean.setEdate(rs.getString("edate"));
				vlist.add(plBean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return vlist;
	}

	public boolean insertPoll(PollListBean plBean, PollItemBean piBean) {
		PreparedStatement pstmt = null;
		boolean flag = false;
		Connection con = null;
		ResultSet rs = null;
		String sql = null;
		try {
			con = DriverManager.getConnection(url, user, pass);
			sql = "insert into tblPollList(num,question,sdate,edate,wdate,type) values(?,?,?,?,sysdate,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, getMaxNum() + 1);
			pstmt.setString(2, plBean.getQuestion());
			pstmt.setString(3, plBean.getSdate());
			pstmt.setString(4, plBean.getEdate());
			pstmt.setInt(5, plBean.getType());
			int result = pstmt.executeUpdate();

			if (result == 1) {
				sql = "insert into tblPollItem values(?,?,?,?)";
				pstmt = con.prepareStatement(sql);
				String item[] = piBean.getItem();
				int itemnum = getMaxNum();
				int j = 0;
				for (int i = 0; i < item.length; i++) {
					if (item[i] == null || item[i].equals(""))
						break;
					pstmt.setInt(1, itemnum);
					pstmt.setInt(2, i);
					pstmt.setString(3, item[i]);
					pstmt.setInt(4, 0);
					j = pstmt.executeUpdate();
				}
				if (j > 0)
					flag = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt);
		}
		return flag;
	}

	public int getMaxNum() {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String sql = null;
		int maxNum = 0;
		try {
			con = DriverManager.getConnection(url, user, pass);
			sql = "select nvl(max(num),0) from tblPollList";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next())
				maxNum = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return maxNum;
	}

	public PollListBean getList(int num) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String sql = null;
		PollListBean plBean = new PollListBean();
		try {
			con = DriverManager.getConnection(url, user, pass);
			if (num == 0)
				sql = "select * from tblPollList order by num desc";
			else
				sql = "select * from tblPollList where num=" + num;

			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				plBean.setQuestion(rs.getString("question"));
				plBean.setType(rs.getInt("type"));
				plBean.setActive(rs.getInt("active"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return plBean;
	}

	public Vector<String> getItem(int num) {

		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String sql = null;
		Vector<String> vlist = new Vector<String>();
		try {
			con = DriverManager.getConnection(url, user, pass);
			if (num == 0)
				num = getMaxNum();
			sql = "select item from tblPollItem where listnum=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				vlist.add(rs.getString(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}

		return vlist;
	}
	
	public Vector<PollItemBean> getView(int num){
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String sql = null;
		Vector<PollItemBean> vlist = new Vector<PollItemBean>();
		try {
			con = DriverManager.getConnection(url, user, pass);
			sql = "select item,count from tblPollItem where listnum=?";
			pstmt = con.prepareStatement(sql);
			if(num == 0) pstmt.setInt(1, getMaxNum());
			else pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				PollItemBean piBean = new PollItemBean();
				String item[] = new String[1];
				item[0] = rs.getString(1);
				piBean.setItem(item);
				piBean.setCount(rs.getInt(2));
				vlist.add(piBean);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt,rs);
		}
		return vlist;
	}
	
	public int sumCount(int num) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String sql = null;
		int count = 0;
		try {
			con = DriverManager.getConnection(url, user, pass);
			sql = "select sum(count) from tblPollItem where listnum=?";
			pstmt = con.prepareStatement(sql);
			if(num == 9 ) pstmt.setInt(1,getMaxNum());
			else pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if(rs.next()) count = rs.getInt(1);
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt ,rs);
		}
		return count;
	}
	
	public boolean updatePoll(int num, String[] itemnum) {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection con = null;
		String sql = null;
		boolean flag = false;
		try {
			con = DriverManager.getConnection(url, user, pass);
			sql = "update tblPollItem set count= count+1 where listnum=? and itemnum = ?";
			pstmt = con.prepareStatement(sql);
			if(num == 0) num = getMaxNum();
			for(int i = 0 ; i < itemnum.length ; i++) {
				if(itemnum[i] == null || itemnum[i].equals("")) break;
				pstmt.setInt(1, num);
				pstmt.setInt(2, Integer.parseInt(itemnum[i]));
				int j = pstmt.executeUpdate();
				if(j > 0) flag = true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt ,rs);
		}
		return flag;
	}
}


