package GameBoard;

import java.sql.*;
import java.util.*;

import BeanEx.Util;
import board.BoardDTO;

public class GameBoardDAO {
	private static GameBoardDAO instance = new GameBoardDAO();
	
	public static GameBoardDAO getInstance() {
		return instance;
	}
	
	private GameBoardDAO() {}
	
	public static Connection getConnection() throws Exception{
		Connection con = null;
		
		try {
			String jdbcUrl = "jdbc:oracle:thin:@localhost:1521:xe";
			String dbId = "scott";
			String dbPass = "1111";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(jdbcUrl, dbId, dbPass);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	
	public void insertArticle(GameBoardDTO article, String boardid) throws Exception{
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		int num = article.getNum();
		int ref = article.getRef();
		int re_step = article.getRe_step();
		int re_level = article.getRe_level();
		
		int number = 0;
		String sql = "";
		
		try {
			pstmt = conn.prepareStatement("select boardser.nextval from dual");
			rs = pstmt.executeQuery();
			
			if(rs.next())
				number = rs.getInt(1) + 1;
			else
				number = 1;
			
			//2 
			if(num != 0) {
				sql = "update gameBoard set re_step = re_step + 1 "
						+ "where ref = ? and re_step> ? and boardid = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, re_step);
				pstmt.setString(3, boardid);
				pstmt.executeUpdate();
				re_step = re_step + 1;
				re_level = re_level + 1;
			} else { 
				ref = number; // �� ��
				re_step = 0;
				re_level = 0;
			} // ============
			
			sql = "insert into gameBoard (num, writer, subject, passwd, reg_date,";
			sql += "ref, re_step, re_level, content, ip, boardid, filename, filesize,readCount)"
					+ "values (?,?,?,?,sysdate,?,?,?,?,?,?,?,?,?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, number);
			pstmt.setString(2, article.getWriter());
			pstmt.setString(3, article.getSubject());
			pstmt.setString(4, article.getPasswd());
			pstmt.setInt(5, ref);
			pstmt.setInt(6, re_step);
			pstmt.setInt(7, re_level);
			pstmt.setString(8, article.getContent());
			pstmt.setString(9, article.getIp());
			pstmt.setString(10, boardid);
			pstmt.setString(11, article.getFilename());
			pstmt.setInt(12, article.getFilesize());
			pstmt.setInt(13, 0);
			
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
	}
	
	
	public int getArticleCount(String boardid, String category, String sentence) throws Exception {
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Connection conn = getConnection();
		int x = 0;
		String sql = "";
		
		try {
			if(category == null || category.equals("")) { //get list
				sql = "select nvl(count(*),0) from gameBoard where boardid = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, boardid);
			} else {	// <form post category �Է�
				sql = "select nvl(count(*),0) from gameBoard where boardid= ? and ? like ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1,  boardid);
				pstmt.setNString(2, category);
				pstmt.setString(3, "%" + sentence + "%");
				}
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				x = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return x;
	}
	
	
	public ArrayList<GameBoardDTO> getArticles(int start, int end, String boardid, String category, String sentence) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ArrayList<GameBoardDTO> articleList = null;
		String query = "";
		
		try {
			conn = getConnection();
			if(category == null || category.equals("")) { 		//get list
				query = " select * from " + " ( select rownum rnum , a.* "
			            + " from ( select * from gameBoard where boardid = ? order by ref desc , re_step)" 
	                     + "a) where rnum between ? and ? ";

				pstmt = conn.prepareStatement(query);
				pstmt.setString(1,  boardid);
				pstmt.setInt(2, start);
				pstmt.setInt(3, end);
			} else {		// <form post category ��
				 query = " select * from " + "( select rownum rnum , a.* "
				            + " from (select * from gameBoard where boardid = ? and " + category 
				            + " like ? order by ref desc , re_step) " + " a)"
				            + " where rnum between ? and ? ";

				
				pstmt = conn.prepareStatement(query);
				pstmt.setString(1, boardid);
				pstmt.setString(2, "%" + sentence + "%");
				pstmt.setInt(3, start);
				pstmt.setInt(4, end);
			}
			rs = pstmt.executeQuery();
				
			if(rs.next()) {
				articleList = new ArrayList<GameBoardDTO>(end);
				
				do {
					GameBoardDTO article = new GameBoardDTO();
					article.setNum(rs.getInt("num"));
	                  article.setWriter(rs.getString("writer"));
	                  article.setSubject(rs.getString("subject"));
	                  article.setPasswd(rs.getString("passwd"));
	                  article.setReg_date(rs.getTimestamp("reg_date"));
	                  article.setReadcount(rs.getInt("readcount"));
	                  article.setRef(rs.getInt("ref"));
	                  article.setRe_step(rs.getInt("re_step"));
	                  article.setRe_level(rs.getInt("re_level"));
	                  article.setContent(rs.getString("content"));
	                  article.setIp(rs.getString("ip"));
	                  article.setFilename(rs.getString("filename"));
	                 
	                  articleList.add(article);
				} while(rs.next());
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return articleList;
	}
	
	
	
	
	
	public GameBoardDTO getArticle(int num, String boardid, boolean readcount) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		GameBoardDTO article = null;
		
		try {
			conn = getConnection();
			if(readcount) {  //false
			pstmt = conn.prepareStatement("update gameBoard set readcount=readcount+1 "
					+ "where num = ? and boardid =?");
			pstmt.setInt(1, num);;
			pstmt.setString(2, boardid);
			pstmt.executeUpdate();
			}
			
			pstmt = conn.prepareStatement("select * from gameBoard where num = ? and boardid =?");
			pstmt.setInt(1, num);
			pstmt.setString(2, boardid);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				article = new GameBoardDTO();
				article.setNum(rs.getInt("num"));
                article.setWriter(rs.getString("writer"));
                article.setSubject(rs.getString("subject"));
                article.setPasswd(rs.getString("passwd"));
                article.setReg_date(rs.getTimestamp("reg_date"));
                article.setReadcount(rs.getInt("readcount"));
                article.setRef(rs.getInt("ref"));
                article.setRe_step(rs.getInt("re_step"));
                article.setRe_level(rs.getInt("re_level"));
                article.setContent(rs.getString("content"));
                article.setIp(rs.getString("ip"));
                article.setFilename(rs.getString("filename"));
			}
		}catch(Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return article;
	}
	
	
	public int updateArticle(GameBoardDTO article, String boardid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbpasswd = "";
		String sql = "";
		int x = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select passwd from gameBoard where num = ?");
			pstmt.setInt(1, article.getNum());
			rs = pstmt.executeQuery();
			if(rs.next()) {
				dbpasswd = rs.getString("passwd");
				if(dbpasswd.equals(article.getPasswd())) {
					sql = "update gameBoard set writer = ? , subject = ? , passwd = ?";
					sql += ", content = ? , filename = ? , filesize = ? where num = ?";
					pstmt = conn.prepareStatement(sql);
					pstmt.setString(1, article.getWriter());
					pstmt.setString(2, article.getSubject());
					pstmt.setString(3, article.getPasswd());
					pstmt.setString(4, article.getContent());
					pstmt.setString(5, article.getFilename());
					pstmt.setInt(6, article.getFilesize());
					pstmt.setInt(7, article.getNum());
					
					pstmt.executeUpdate();
					x = 1;
				} else {
					x = 0;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return x;
	}
	
	
	public int deleteArticle(int num, String passwd, String boardid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String dbpasswd = "";
		String sql = "";
		int x = -1;
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select passwd from gameBoard where num = ?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				dbpasswd = rs.getString("passwd");
				if(dbpasswd.equals(passwd)) {
					sql = "delete from gameBoard where num = ?";
					// sql = "delete from board where ref = ?";   // ��۱��� �Բ� ����
					pstmt = conn.prepareStatement(sql);
					pstmt.setInt(1, num);
					
					pstmt.executeUpdate();
					
					x = 1;
				} else {
					x = 0;		//��й�ȣ Ʋ��
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return x;
	}
}
