package rank;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class RankDAO {

	public static Connection getConnection() throws Exception {
		Connection con = null;
		try {
			String jdbcUrl = "jdbc:oracle:thin:@localhost:1521:xe";
			String dbId = "scott";
			String dbPass = "1111";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(jdbcUrl, dbId, dbPass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<RankDTO> getMyRank(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		RankDTO myRank = null;
		ArrayList<RankDTO> myList = new ArrayList<RankDTO>();
		try {
			conn = getConnection();
			sql = "select * from prorank where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs= pstmt.executeQuery();
			
			while(rs.next()) {
				myRank = new RankDTO();
				myRank.setNo(rs.getInt("no"));
				myRank.setLv(rs.getInt("lv"));
				myRank.setTime(rs.getInt("time"));
				myRank.setTotalPoint(rs.getInt("totalpoint"));
				myRank.setId(rs.getString("id"));
				myList.add(myRank);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return myList;
	}
	
	public ArrayList<RankDTO> getAllRank() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		RankDTO Rank = null;
		ArrayList<RankDTO> List = new ArrayList<RankDTO>();
		try {
			conn = getConnection();
			sql = "select * from prorank ORDER BY totalpoint DESC";
			pstmt = conn.prepareStatement(sql);
			rs= pstmt.executeQuery();
			
			while(rs.next()) {
				Rank = new RankDTO();
				Rank.setNo(rs.getInt("no"));
				Rank.setLv(rs.getInt("lv"));
				Rank.setTime(rs.getInt("time"));
				Rank.setTotalPoint(rs.getInt("totalpoint"));
				Rank.setId(rs.getString("id"));
				List.add(Rank);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}
		return List;
	}
	

	public boolean insertRank(int lv ,int time, int totalpoint, String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs =null;
		String sql = null;
		boolean flag = false;
		int no = 1;
		try {
			conn = getConnection();
			sql = "select Max(no) from prorank";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				no = rs.getInt("Max(no)")+1;
			}
			
			sql = "insert into prorank(no,lv,time,totalpoint,id)values(?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no);
			pstmt.setInt(2, lv);
			pstmt.setInt(3, time);
			pstmt.setInt(4, totalpoint);
			pstmt.setString(5, id);
			
			if(pstmt.executeUpdate()== 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt);
		}
		return flag;
	}

	public boolean deleteRank(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			conn = getConnection();
			sql = "delete from prorank where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			
			if(pstmt.executeUpdate()== 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt);
		}
		return flag;
	}
	
}
