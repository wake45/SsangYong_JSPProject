
	package board;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class BoardDAO {

	private static BoardDAO instance = null;

	public static BoardDAO getInstance() throws IOException {
		if (instance == null) {
			instance = new BoardDAO();
		}
		return instance;
	}

	private BoardDAO() {
	}

	public static Connection getConnection() throws Exception {
		Connection con = null;
		try {
			String jdbcUrl = "jdbc:oracle:thin:@localhost:1521:xe";
			String dbId = "scott";
			String dbPass = "1111";
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection(jdbcUrl, dbId, dbPass);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

	public void insertArticle(BoardDTO article, String boardid) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		int num = article.getNum();
		int ref = article.getRef();
		int re_step = article.getRe_step();
		int re_level = article.getRe_level();

		int number = 0;
		String sql = "";
		try {
			con = getConnection();
			pstmt = con.prepareStatement("select boardser1.nextval from dual");
			rs = pstmt.executeQuery();
			if (rs.next())
				number = rs.getInt(1) + 1;
			else
				number = 1;

			if (num != 0) {
				sql = "update proboard2 set re_step = re_step+1" + "where ref = ? and re_step>? and boardid = ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, ref);
				pstmt.setInt(2, re_step);
				pstmt.setString(3, boardid);
				pstmt.executeUpdate();
				re_step = re_step + 1;
				re_level = re_level + 1;
			} else {
				ref = number;
				re_step = 0;
				re_level = 0;
			}

			sql = "insert into proboard2 (num, writer, email, subject," + " passwd, reg_date,ref, re_step, re_level,"
					+ " content, ip, boardid, filename, filesize) " + "values(?,?,?,?,?" + ",sysdate,?,?,?"
					+ ",?,?,?,?,?)";

			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, number);
			pstmt.setString(2, article.getWriter());
			pstmt.setString(3, article.getEmail());
			pstmt.setString(4, article.getSubject());
			pstmt.setString(5, article.getPasswd());
			pstmt.setInt(6, ref);
			pstmt.setInt(7, re_step);
			pstmt.setInt(8, re_level);
			pstmt.setString(9, article.getContent());
			pstmt.setString(10, article.getIp());
			pstmt.setString(11, boardid);
			pstmt.setString(12, article.getFilename());
			pstmt.setInt(13, article.getFilesize());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
	}

	public int getArticleCount(String boardid, String category, String sentence) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int count = 0;
		String sql = "";
		try {
			conn = getConnection();

			if (category == null || category.equals("")) {
				sql = "select nvl(count(*),0) from proboard2 where boardid = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, boardid);

			} else {
				sql = "select nvl(count(*),0) from proboard2 where boardid = ? and " + category + "like ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, boardid);
				pstmt.setString(2, "%" + sentence + "%");
			}
			rs = pstmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(conn, pstmt, rs);
		}

		return count;
	}

	public ArrayList<BoardDTO> getArticles(int startRow, int endRow, String boardid, String category, String sentence) {
		ArrayList<BoardDTO> articleList = null;
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";

		try {
			con = getConnection();
			if (category == null || category.equals("")) {
				sql = "select * from" + "(select rownum rnum, a.* "
						+ "from (select * from proboard2 where boardid = ?  order by  ref desc, re_step)"
						+ "a) where rnum between ? and ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, boardid);
				pstmt.setInt(2, startRow);
				pstmt.setInt(3, endRow);
			} else {
				sql = "select * from" + "(select rownum rnum, a.* " + "from (select * from proboard2 where boardid = ? and "
						+ category + " like ? order by  ref desc, re_step)" + "a) where rnum between ? and ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, boardid);
				pstmt.setString(2, "%" + sentence + "%");
				pstmt.setInt(3, startRow);
				pstmt.setInt(4, endRow);
			}
			rs = pstmt.executeQuery();
			if (rs.next()) {
				articleList = new ArrayList<BoardDTO>(endRow);
				do {
					BoardDTO article = new BoardDTO();
					article.setNum(rs.getInt("num"));
					article.setWriter(rs.getString("writer"));
					article.setEmail(rs.getString("email"));
					article.setSubject(rs.getString("subject"));
					article.setPasswd(rs.getString("passwd"));
					article.setReg_date(rs.getTimestamp("reg_date"));
					article.setReadcount(rs.getInt("readcount"));
					article.setRef(rs.getInt("ref"));
					article.setRe_step(rs.getInt("re_step"));
					article.setRe_level(rs.getInt("re_level"));
					article.setContent(rs.getString("content"));
					article.setIp(rs.getString("ip"));
					article.setFilename(rs.getString("filename"));
					articleList.add(article);
				} while (rs.next());

			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return articleList;
	}

	public BoardDTO getArticle(int num, String boardid, boolean readcount) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "";
		BoardDTO article = null;

		try {
			con = getConnection();
			if (readcount) {
				sql = "update proboard2 set readcount = readcount+1 where num = ? and boardid=?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1, num);
				pstmt.setString(2, boardid);
				pstmt.executeUpdate();
			}

			sql = "select * from proboard2 where num = ? and boardid = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.setString(2, boardid);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				article = new BoardDTO();
				article.setNum(rs.getInt("num"));
				article.setWriter(rs.getString("writer"));
				article.setEmail(rs.getString("email"));
				article.setSubject(rs.getString("subject"));
				article.setPasswd(rs.getString("passwd"));
				article.setReg_date(rs.getTimestamp("reg_date"));
				article.setReadcount(rs.getInt("readcount"));
				article.setRef(rs.getInt("ref"));
				article.setRe_step(rs.getInt("re_step"));
				article.setRe_level(rs.getInt("re_level"));
				article.setContent(rs.getString("content"));
				article.setIp(rs.getString("ip"));
				article.setFilename(rs.getString("filename"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return article;
	}

	public int updateArticle(BoardDTO article, String boardid) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String dbpasswd = "";
		int check = -1;
		String sql = "";
		try {
			con = getConnection();
			pstmt = con.prepareStatement("select passwd from proboard2 where num = ?");
			pstmt.setInt(1, article.getNum());
			rs = pstmt.executeQuery();
			if (rs.next()) {
				dbpasswd = rs.getString("passwd");

				if (dbpasswd.equals(article.getPasswd())) {
					sql = "update proboard2 set WRITER = ? , EMAIL = ? , subject = ? , passwd = ?, content=?, filename =?, filesize =? where num =?";
					pstmt = con.prepareStatement(sql);
					pstmt.setString(1, article.getWriter());
					pstmt.setString(2, article.getEmail());
					pstmt.setString(3, article.getSubject());
					pstmt.setString(4, article.getPasswd());
					pstmt.setString(5, article.getContent());
					pstmt.setString(6, article.getFilename());
					pstmt.setInt(7, article.getFilesize());
					pstmt.setInt(8, article.getNum());
					pstmt.executeUpdate();
					check = 1;
				} else
					check = 0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return check;
	}

	public int deleteArticle(int num, String passwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String dbpasswd = "";
		int check = -1;
		String sql = "";
		int ref = 0;

		try {
			con = getConnection();
			pstmt = con.prepareStatement("select passwd, ref from proboard2 where num = ?");
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				ref = rs.getInt("ref");
				dbpasswd = rs.getString("passwd");
				if (dbpasswd.equals(passwd)) {
					sql = "delete proboard2 where ref = ? and num >= ?";
					pstmt = con.prepareStatement(sql);
					pstmt.setInt(1, ref);
					pstmt.setInt(2, num);
					pstmt.executeUpdate();
					check = 1;
				} else
					check = 0;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt, rs);
		}
		return check;
	}
}