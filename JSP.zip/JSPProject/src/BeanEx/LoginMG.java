package BeanEx;

import java.sql.*;

public class LoginMG {
	
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "1111";
	
	public LoginMG(){
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean LoginCheckId(String id) throws SQLException, ClassNotFoundException{
		
		boolean flag = false;
		Connection con = null;
		PreparedStatement stmt = null;
						
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.prepareStatement("select * from proMember where id='" + id + "'");
			
			if(stmt.executeUpdate() == 1) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}
	public boolean LoginCheckPwd(String id,String pwd) throws SQLException, ClassNotFoundException{
		
		boolean flag = false;
		Connection con = null;
		PreparedStatement stmt = null;
						
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.prepareStatement("select * from proMember where id= '" + id + "' and pwd = '" + pwd + "'");
			
			if(stmt.executeUpdate() == 1) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}
	
	public String[] FindId(String name, String email) throws SQLException, ClassNotFoundException {
		
		String flag[] = new String[50];
		int cnt = 0;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select id from proMember where name='" + name + "'and email='"+email+"'");
			
			while(rs.next()) {
				flag[cnt++] = rs.getString("id");
				if(cnt == 50) {
					flag[49] = "ã�� �� �ִ� ���̵�� 49�� ���� �Դϴ�.";
					break;
				}
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}
	public String FindPwd(String id) throws SQLException, ClassNotFoundException {
		
		String flag = "";
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
				
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select pwd from proMember where id='" + id + "'");
			
			if(rs.next()) {
				flag = rs.getString("pwd");
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}
	
	public String FindName(String id) throws SQLException, ClassNotFoundException {
		
		String flag = "";
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
				
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select name from proMember where id='" + id + "'");
			
			if(rs.next()) {
				flag = rs.getString("name");
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}

	public String FindEmail(String id) throws SQLException, ClassNotFoundException {
		
		String flag = "";
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
				
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select email from proMember where id='" + id + "'");
			
			if(rs.next()) {
				flag = rs.getString("email");
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}
	
	public boolean RemoveMem(String id) throws SQLException, ClassNotFoundException {
		
		boolean flag = false;
		Connection con = null;
		PreparedStatement stmt = null;
						
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.prepareStatement("delete from proMember where id=?");
			stmt.setString(1, id);
			
			if(stmt.executeUpdate() == 1) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		return flag;
	}
}
