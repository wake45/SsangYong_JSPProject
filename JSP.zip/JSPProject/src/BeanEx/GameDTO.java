package BeanEx;

public class GameDTO {
	private String id;
	private String score;
	private int miss;
	private String timer;
	
	@Override
	public String toString() {
		return "GameDTO [id=" + id + ", score=" + score + ", miss=" + miss + ", timer=" + timer + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getScore() {
		return score;
	}

	public void setScore(String score) {
		this.score = score;
	}

	public int getMiss() {
		return miss;
	}

	public void setMiss(int miss) {
		this.miss = miss;
	}

	public String getTimer() {
		return timer;
	}

	public void setTimer(String timer) {
		this.timer = timer;
	}
	
	

}
