package BeanEx;

import java.sql.*;
import java.util.ArrayList;

public class WordMG {
	
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "1111";
	
	public WordMG(){
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String[] findWords(int num) {
		String result[] = new String[2];

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;		
		String sql = null;
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			sql = "select word,explain from wordDB where n=" + num;
			rs = stmt.executeQuery(sql);
			if(rs.next()) {
				result[0] = rs.getString("word");
				result[1] = rs.getString("explain");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, stmt, rs);
		}
		return result;
	}
	
	public int FindCount(String userId) {
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;		
		String sql = null;
		int flag = -1;
		try {
			con = DriverManager.getConnection(url,user,pass);
			sql = "select num from resultDB where id=?";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, userId);
			rs = stmt.executeQuery();
			
			if(rs.next()) {
				flag = rs.getInt(1);
			}else {
				//������ ������ ���� ���� 
				sql = "insert into resultDB values(?,0)";
				stmt = con.prepareStatement(sql);
				stmt.setString(1, userId);
				flag = stmt.executeUpdate();
				flag = 0;
			}
			return flag;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, stmt, rs);
		}
		return flag; //-1�̸�DB���� 0�̸� insert �������� count
	}
	
	public int nextRound(String userid, int count) {		
		Connection con = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;		
		String sql = null;
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			sql = "select num from resultDB where id = ?";
			stmt = con.prepareStatement(sql);
			stmt.setString(1, userid);
			rs = stmt.executeQuery();
			if(rs.next()) {
				if(count == rs.getInt(1)+1) {
					sql = "update resultDB set num=num+1 where id = ?";
					stmt = con.prepareStatement(sql);
					stmt.setString(1, userid);
					return stmt.executeUpdate();
				}else{
					return count+1; //���� ����
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, stmt, rs);
		}
		return -1;
	}
	
	public ArrayList<ResultDTO> getRankList() {
		String sql = "select * from resultDB order by num desc";
		Connection conn = null;
		ResultSet rs = null;
		ArrayList<ResultDTO> flag = new ArrayList<ResultDTO>();
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ResultDTO bdto = new ResultDTO();
				bdto.setId(rs.getString(1));
				bdto.setNum(rs.getInt(2));
				flag.add(bdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}
			
		return flag;
	}
}
