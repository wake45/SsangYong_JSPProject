package BeanEx;

import java.sql.*;
import java.util.*;

public class GameDAO {

	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "1111";
	
	public GameDAO(){
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public boolean insertUserScore(GameDTO bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean flag = false;
		
		try {
			con = DriverManager.getConnection(url, user, pass);
			
				pstmt = con.prepareStatement("insert into user_rank(id,score,miss,timer) values(?,?,?,?)");
				
				pstmt.setString(1, bean.getId());
				pstmt.setString(2, bean.getScore());
				pstmt.setInt(3, bean.getMiss());
				pstmt.setString(4, bean.getTimer());
			
			
			if(pstmt.executeUpdate() == 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt);
		}
		return flag;
	}
	
	public boolean updateUserScore(GameDTO bean) {
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean flag = false;
		
		try {
			con = DriverManager.getConnection(url, user, pass);
			
			pstmt = con.prepareStatement("update user_rank set score=?, miss=?, timer=? where id =?");
			
			pstmt.setString(4, bean.getId());
			pstmt.setString(1, bean.getScore());
			pstmt.setInt(2, bean.getMiss());
			pstmt.setString(3, bean.getTimer());
			
			if(pstmt.executeUpdate() == 1) {
				flag = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt);
		}
		return flag;
	}
	
	public boolean checkUserId(String id) {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		boolean flag = false;
		
		try {
			con = DriverManager.getConnection(url, user, pass);
			
			stmt = con.createStatement();
			rs = stmt.executeQuery("select id from user_rank where id = '" + id + "'");
			
			if(rs.next()) {
				flag = false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, stmt, rs);
		}
		return flag;
	}

	
	
	public List<GameDTO> getUserList(){
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		List<GameDTO> li = new ArrayList<GameDTO>();
		
		try {
			con = DriverManager.getConnection(url, user, pass);
			/*
			 * pstmt = con.prepareStatement(" select * from (\r\n" +
			 * "    select  rownum rank, a.* from\r\n" +
			 * "    (select * from user_rank order by score desc) a)");
			 */
			pstmt = con.prepareStatement("select rank() over(order by score desc) rk, id,score,timer from user_rank");
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				GameDTO bean = new GameDTO();
				bean.setId(rs.getString("id"));
				bean.setScore(rs.getString("score"));
				/* bean.setMiss(rs.getInt("miss")); */
				bean.setTimer(rs.getString("timer"));
				
				li.add(bean);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Util.close(con, pstmt);
		}
		return li;
	}
}
