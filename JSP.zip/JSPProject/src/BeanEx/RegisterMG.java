package BeanEx;

import java.sql.*;

public class RegisterMG {
	
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "1111";
	
	public RegisterMG(){
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean insertMember(MemberBean bean) throws SQLException, ClassNotFoundException {
		
		boolean flag = false;
		Connection con = null;
		PreparedStatement stmt = null;		
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.prepareStatement("insert into proMember values(? ,? ,? ,?)");
			stmt.setString(1, bean.getId());
			stmt.setString(2, bean.getPwd());
			stmt.setString(3, bean.getName());
			stmt.setString(4, bean.getEmail());
				
			if(stmt.executeUpdate() == 1) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		System.out.println(flag);
		return flag;
	}
	
	public boolean checkId(String id) throws ClassNotFoundException, SQLException {
		
		boolean flag = false;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select id from proMember where id = '" + id + "'");
		
			if(rs.next()) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt,rs);
			}catch ( Exception e) {}
		}
		return flag;
	}
	
	public boolean UpdateMember(String id,String pwd,String name,String email) throws ClassNotFoundException, SQLException {
		
		boolean flag = false;
		Connection con = null;
		PreparedStatement stmt = null;
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.prepareStatement("update proMember set pwd=?,name=?,email=? where id=?");
			stmt.setString(1,pwd);
			stmt.setString(2,name);
			stmt.setString(3,email);
			stmt.setString(4,id);
		
			if(stmt.executeUpdate() == 1) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		return flag;
	}
}
