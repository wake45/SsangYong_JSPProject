package BeanEx;

public class BoardDTO {
	private int n;
	private String title;
	private String userid;
	private String hiredate;
	private int readcount;
	private String content;
	private int available;
	
	@Override
	public String toString() {
		return "BoardDTO [n=" + n + ", title=" + title + ", userid=" + userid + ", hiredate=" + hiredate
				+ ", readcount=" + readcount + ", content=" + content + ", available=" + available + "]";
	}
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	public int getReadcount() {
		return readcount;
	}
	public void setReadcount(int readcount) {
		this.readcount = readcount;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getAvailable() {
		return available;
	}
	public void setAvailable(int available) {
		this.available = available;
	}
}
