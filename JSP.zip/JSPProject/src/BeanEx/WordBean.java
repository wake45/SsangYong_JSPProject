package BeanEx;

public class WordBean {
	private int seq;
	private int leng;
	private String word;
	private String explan;
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public int getLeng() {
		return leng;
	}
	public void setLeng(int leng) {
		this.leng = leng;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getExplan() {
		return explan;
	}
	public void setExplan(String explan) {
		this.explan = explan;
	}
}
