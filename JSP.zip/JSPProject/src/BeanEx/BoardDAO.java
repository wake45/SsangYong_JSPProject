package BeanEx;

import java.sql.*;
import java.util.*;

public class BoardDAO {
	
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "1111";
		
	public BoardDAO(){
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//오늘날짜 가져옴
	public String getDate() {
		String sql = "select TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') from dual";
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
		
		return ""; //DB����
	}
	
	//다음 게시물 번호 가져옴
	public int getNext() {
		int flag = 1;
		String sql = "select n from proBoard order by 1 desc";
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				flag =  rs.getInt(1) + 1;
			}
			return flag;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return -1;//DB����
	}
	
	//글쓰기
	public int write(String title, String userid, String content) {
		String sql = "Insert into proboard values(?,?,?,?,?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, title);
			pstmt.setString(3, userid);
			pstmt.setString(4, getDate());
			pstmt.setInt(5, 0);
			pstmt.setString(6, content);
			pstmt.setInt(7, 1);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}
			
		return -1;//DB����
	}
	
	//게시판 글 목록
	public ArrayList<BoardDTO> getList(int pageNumber){
		String sql = "select * from (select * from proBoard where n < ? and available = 1 order by n desc) where rownum <= 10 ";
		Connection conn = null;
		ResultSet rs = null;
		ArrayList<BoardDTO> flag = new ArrayList<BoardDTO>();
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardDTO bdto = new BoardDTO();
				bdto.setN(rs.getInt(1));
				bdto.setTitle(rs.getString(2));
				bdto.setUserid(rs.getString(3));
				bdto.setHiredate(rs.getString(4));
				bdto.setReadcount(rs.getInt(5));
				bdto.setContent(rs.getString(6));
				bdto.setAvailable(rs.getInt(7));
				flag.add(bdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return flag;
	}
	
	//다음 페이지가 있는지 여부 (글 10개씩 짤라서 보여줌)
	public boolean nextPage(int pageNumber) {
		String sql = "select * from proBoard where n < ? and available = 1";
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;

		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return true;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return false;//DB����
	}
	
	//모든 게시물 목록
	public BoardDTO getBoardDTO(int n) {
		String sql = "select * from proBoard where n = ?";
		Connection conn = null;
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		BoardDTO bdto = new BoardDTO();
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				bdto.setN(n); 
				bdto.setTitle(rs.getString("title"));
				bdto.setUserid(rs.getString("userid"));
				bdto.setHiredate(rs.getString("hiredate"));
				bdto.setReadcount(rs.getInt("readCount"));
				bdto.setContent(rs.getString("content"));
				bdto.setAvailable(rs.getInt("available"));
				sql = "update proBoard set readcount = readcount+1 where n = ?";
				pstmt = conn.prepareStatement(sql);
				pstmt.setInt(1, n);
				pstmt.executeUpdate();
				return bdto;
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return null;//DB����
	}
	
	//게시물 수정
	public int update(int n,String title,String content) {
		String sql = "update proBoard set title = ? , content = ? where n = ? ";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			pstmt.setInt(3, n);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}
			
		return -1;//DB����
	}
	
	//게시물 삭제
	public int delete(int n) {
		String sql = "update proBoard set available = 0  where n = ? ";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}	
		return -1;//DB����
	}
	
	//댓글 쓰기
	public int commentwrite(int n,String comm,String userid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select rown from boardcomment where n = ? order by 1 desc";
		int rown = 0;
	
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,n);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				rown = rs.getInt(1);
			}
			
			sql = "Insert into boardcomment values(?,?,?,?,TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS'))";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, ++rown);
			pstmt.setInt(2,n);
			pstmt.setString(3, comm);
			pstmt.setString(4, userid);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return -1;//DB����
	}
	
	//댓글 목록 불러오기
	public ArrayList<BoardCommentDTO> getCommentList(int n) {
		String sql = "select * from boardcomment where n = ? order by rown desc";
		Connection conn = null;
		ResultSet rs = null;
		ArrayList<BoardCommentDTO> flag = new ArrayList<BoardCommentDTO>();
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardCommentDTO bdto = new BoardCommentDTO();
				bdto.setRown(rs.getInt(1));
				bdto.setN(n);
				bdto.setComm(rs.getString(3));
				bdto.setUserid(rs.getString(4));
				bdto.setHiredate(rs.getString(5));
				flag.add(bdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return flag;
	}
	
	//댓글 삭제
	public int deleteComment(int rown,int n) {
		String sql = "delete from boardcomment where rown=? and n=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, rown);
			pstmt.setInt(2, n);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}
			
		return -1; //DB���� or ��x
	}
	
	//댓글 갯수 (글 목록 제목 옆에)
	public int Commentnum(int n) {
		String sql = "select count(*) from boardcomment where n=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return -1; //DB����
	}
	
	//이미지 업로드
	public int upload(int n,String fileName, String fileRealName) {
		String sql = "Insert Into boardFile values(?,?,?)";
		Connection conn = null;
		PreparedStatement pstmt = null;
		
		if(!(fileName.toUpperCase().contains(".JPG") ||
		   fileName.toUpperCase().contains(".PNG") ||
		   fileName.toUpperCase().contains(".JPEG") ||
		   fileName.toUpperCase().contains(".GIF") ||
		   fileName.toUpperCase().contains(".BMP") ||
		   fileName.toUpperCase().contains(".RLE") ||
		   fileName.toUpperCase().contains(".TIF") ||
		   fileName.toUpperCase().contains(".TIFF") ||
		   fileName.toUpperCase().contains(".APNG") ||
		   fileName.toUpperCase().contains(".SVG"))) {
			return -2; //이미지형식이 맞지 않을때
		}
		
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			pstmt.setString(2, fileName);
			pstmt.setString(3, fileRealName);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}
			
		return -1; //DB오류
	}
	
	//게시물 이미지 가져오기
	public ArrayList<FileDTO> getimgList(int n) {
		String sql = "select * from boardfile where n = ?"; //순서문제??
		Connection conn = null;
		ResultSet rs = null;
		ArrayList<FileDTO> flag = new ArrayList<FileDTO>();
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				FileDTO bdto = new FileDTO();
				bdto.setN(rs.getInt(1));
				bdto.setFileName(rs.getString(2));
				bdto.setFileRealName(rs.getString(3));
				flag.add(bdto);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return flag;
	}
	
	//게시물 수정시 이미지 삭제
	public int deleteimg(int n,String FileRealName) {
		String sql = "delete from boardFile where n=? and fileRealName=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			pstmt.setString(2, FileRealName);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt);
		}
			
		return -1; //DB���� or ��x
	}
	
	//이미지 여부
	public int photo(int n) {
		String sql = "select * from boardfile where n=?";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DriverManager.getConnection(url,user,pass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, n);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return 1;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn, pstmt, rs);
		}
			
		return 0; 
	}
}
