package BeanEx;

public class BoardCommentDTO {
	private int rown;
	private int n;
	private String comm;
	private String userid;
	private String hiredate;
	public int getRown() {
		return rown;
	}
	public void setRown(int rown) {
		this.rown = rown;
	}
	public int getN() {
		return n;
	}
	public void setN(int n) {
		this.n = n;
	}
	public String getComm() {
		return comm;
	}
	public void setComm(String comm) {
		this.comm = comm;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	@Override
	public String toString() {
		return "BoardCommentDTO [rown=" + rown + ", n=" + n + ", comm=" + comm + ", userid=" + userid + ", hiredate="
				+ hiredate + "]";
	}
	
}
