package game;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/SaveServlet")
public class SaveServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8"); //�ѱ����ڵ�
		response.setContentType("text/html;charset=UTF-8"); //�ѱ����ڵ�
		
		HttpSession session = request.getSession();
		String id = (String) session.getAttribute("idKey"); //id��
		
		int score =  Integer.parseInt(request.getParameter("score")); //ShootingGame.jsp���� ���ӿ��� �Ǹ� form������ score�� submit�� ��

		int check = new GameDAO().checkgame(id);
		System.out.println(check);
		 int result = 0;
	     if(check == 1) {
	        result = new GameDAO().updatescore(id, score);
	     } else if (check == 0 ) {
	        result = new GameDAO().insertscore(id, score);
	     }
		response.sendRedirect("/JSPProject/game2/ShootingGameRank.jsp");
	}
}
