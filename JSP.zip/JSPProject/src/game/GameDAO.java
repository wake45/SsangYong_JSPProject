package game;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bbs.Bbs;
import bbs.Util;
import game.Game;

public class GameDAO {
	private String dbURL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String dbId = "scott";
	private String dbPass = "1111";
	
	public GameDAO() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/*
	//���� ���̵�� ���� ��� (�Ⱦ��� ����)
	public int setGamescore(String id, String score) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO ShootingGameRank(id, score) VALUES(?, ?)";
		try {
			conn = DriverManager.getConnection(dbURL, dbId, dbPass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, score);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn,pstmt);
		}
		return -1;
	}
*/
	//��ŷ �� �˻���� ����
	public ArrayList<Game> search(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id, score, ROW_NUMBER() OVER(ORDER BY score) from ShootingGameRank WHERE id LIKE ?";
		ArrayList<Game> list = new ArrayList<Game>();
		try {
			conn = DriverManager.getConnection(dbURL, dbId, dbPass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%" + id + "%");
			rs = pstmt.executeQuery();
			while(rs.next()) { 
				Game game = new Game();
				game.setId(rs.getString(1));
				game.setScore(rs.getInt(2));
				game.setRank(rs.getInt(3));
				list.add(game);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn,pstmt,rs);
		}
		return list;
	}
	
	//���� ���� ���屸��
	public int updatescore(String id, int score) {
		System.out.println(id);
		System.out.println(score);
		Connection conn = null;
		PreparedStatement pstmt = null;
		String sql = "UPDATE ShootingGameRank SET score = ? WHERE id = ?";
		try {
			conn = DriverManager.getConnection(dbURL, dbId, dbPass);
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, score);
			pstmt.setString(2, id);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn,pstmt);
		}
		return -1;
	}
	
	   //게임 아이디, 점수등록하기
	   public int insertscore(String id, int score) {
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      String sql = "INSERT INTO ShootingGameRank VALUES(?, ?)";
	      try {
	         conn = DriverManager.getConnection(dbURL, dbId, dbPass);
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, id);
	         pstmt.setInt(2, score);
	         return pstmt.executeUpdate();
	      } catch (Exception e) {
	         e.printStackTrace();
	      }finally {
	         Util.close(conn,pstmt);
	      }
	      return -1;
	   }
	
	   
	   //아이디 중복 확인 (첫게임인지 확인)
	   public int checkgame(String id) {
	      Connection conn = null;
	      PreparedStatement pstmt = null;
	      ResultSet rs = null;
	      String sql = "SELECT id FROM ShootingGameRank WHERE id = ?";
	      try {
	         conn = DriverManager.getConnection(dbURL, dbId, dbPass);
	         pstmt = conn.prepareStatement(sql);
	         pstmt.setString(1, id);
	         rs = pstmt.executeQuery();
	         if(rs.next()) { //아이디가 있으면 1리턴
	            return 1;
	         }
	         return 0; //아이디가 없으면 0 리턴
	      } catch (Exception e) {
	         e.printStackTrace();
	      }finally {
	         Util.close(conn,pstmt);
	      }
	      return -1; // 오류 발생시 -1
	   }
	//��ŷ���� ����
	public ArrayList<Game> getGameRank() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select id, score, ROW_NUMBER() OVER(ORDER BY SCORE DESC) from ShootingGameRank";
		ArrayList<Game> list = new ArrayList<Game>();
		try {
			conn = DriverManager.getConnection(dbURL, dbId, dbPass);
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Game game = new Game();
				game.setId(rs.getString(1));
				game.setScore(rs.getInt(2));
				game.setRank(rs.getInt(3));
				list.add(game);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(conn,pstmt,rs);
		}
		return list;
	}
	
}
