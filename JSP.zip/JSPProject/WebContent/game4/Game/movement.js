function createObject(){
	// y축 랜덤 출력
		
		var enemys = [];
		var enemy1 = new Image();
		var enemy2 = new Image();
		enemy1 = "ufo.png";
		enemy2 = "meteo1.png";
		var enemy_img = [enemy1,enemy2];
		function random(num){
			return parseInt(Math.random()*num);
		} 
		
		var startText = document.getElementById('startText');
		startText.style.display = "none";
	
		
			
			// 랜덤 생성 설정
			var addObject = setInterval(function() {
				
				
				
				var d = document.createElement('img');  //div 태그 생성
				document.getElementById('main').appendChild(d);   // main 태그에 자식(div태그) 생성
				enemys.push(d);		// enemys 배열에 저장
				
				
				// div 스타일 설정
				d.id = "enemy";
				d.style.left = "900px";
				d.style.top = random(600)+10 + 'px';
				d.src = enemy_img[random(2)];
				
				// 점수 계산
				var score = document.getElementById('num');
				
				d.onclick = function(){
					//alert("onclick");
					document.getElementById('main').removeChild(this);
					delete(this);
					plusScore();
				}
				
			}, 1000);
			
			
			// 움직임 설정
			var moveObject = setInterval(function() {
				
				// 점수 계산
				var score = document.getElementById('num');
				var miss_count = document.getElementById('miss');
				
				for(var i in enemys){
					var x = parseInt(enemys[i].style.left);   // parseInt => 'px' 때문
					enemys[i].style.left = x - 2 + 'px';		// 속도
					
					
					/****************************************
					 * 
					 * 
					 *  장애물 이동 속도가 컴퓨터마다 다르게 보일 수 있음
					 *  (학원 컴퓨터에서는 적당한 속도였지만 제 노트북에선 엄청 느리게 움직이네요...)
					 * 
					 * **************************************
					 */
					
					if(x < 100 ){
						try{  
						document.getElementById("main").removeChild(enemys[i]); // Dom에서 삭제
						delete(enemys[i]);		// 배열에서 삭제
						plusMiss();
						minusScore();
						
						} catch(e){}
					}
				}
			
			}, 1);
			
			
			
			// 타이머
			var time = 0;
			var min = '';
			var sec = '';
			
			var timer = setInterval(function() {
				min = parseInt(time/60);
				sec = time % 60;
				
				/*document.getElementById('timer').innerHTML = min + '분 ' + sec+ '초';*/
				getTimer();
				time++;
				
				
				if(time == 10){			// 게임 종료 시간
					clearInterval(timer);
					
					setTimeout(() => {
						var clearText = document.createElement('h1');
						clearText.id = "clearText";
						document.getElementById('main').appendChild(clearText);
						
						var saveScore = document.getElementById('saveMyScore');
						
						/*document.getElementById('main').appendChild(saveScore);
						saveScore.id = "saveMyScore";
						saveScore.type= "submit";
						saveScore.onClick = "saveScore()";*/
						
						clearText.style.visibility = "visible";
						saveScore.style.visibility = "visible";
						
						
						if(document.getElementById("num").innerHTML >= 3500){
							clearText.innerHTML = "STAGE CLEAR";
							/*saveScore.value = "점수 저장하기";*/
						} else {
							clearText.innerHTML = "GAME OVER"
							/*saveScore.value = "점수 저장하기";	*/
						}
						
					}, 11000);		// 타이머 종료 시간 - 게임 종료 1초 후 점수 저장버튼 또는 게임오버 출력
					
				
				}
			}, 1000)
			
			
			setTimeout(function() {				// 장애물 생성 종료 시간
				clearInterval(addObject)
			}, 10000)							// 빠른 진행을 위해 10초로 설정
			
			function plusScore(){
				document.getElementById("num").value  = (Number)(document.getElementById('num').value) + 100;
			}
			function minusScore(){
				document.getElementById("num").value  = (Number)(document.getElementById('num').value) - 50;
			}
			function plusMiss(){
				document.getElementById("avoid").value  = (Number)(document.getElementById('avoid').value) + 1;
			}
			function getTimer(){
				document.getElementById("timer").value = min + '분' + sec+ '초';
			}
		
}