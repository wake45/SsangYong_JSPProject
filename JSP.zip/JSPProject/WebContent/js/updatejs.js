function inputCheck(){

	if(document.regFrm.pwd.value == ""){
		alert("비밀번호 확인하세요");
		document.regFrm.pwd.focus();
		return false;
	}
	
	if(!((document.regFrm.pwd.value).length > 6 && (document.regFrm.pwd.value).length < 20)){
		alert("비밀번호는 7~20글자로 입력하세요");
		document.regFrm.pwd.focus();
		return false;
	}
	
	var pattern1 = /[~!@\#$%<>^&*]/; 
	if(!pattern1.test(document.regFrm.pwd.value)){
        alert("비밀번호는 특수문자를 포함하여야 합니다.");
        return false;
    }    
	
	if(document.regFrm.pwdck.value == ""){
		alert("비밀번호 재입력을 확인하세요");
		document.regFrm.pwdck.focus();
		return false;
	}
	
	if(document.regFrm.pwd.value != document.regFrm.pwdck.value){
		alert("비밀번호가 일치하지 않습니다.");
		document.regFrm.pwdck.value="";
		document.regFrm.pwdck.focus();
		return false;
	}
	
	if(document.regFrm.name.value == ""){
		alert("이름을 확인하세요");
		document.regFrm.name.focus();
		return false;
	}
	
	if(!((document.regFrm.name.value).length > 1 && (document.regFrm.name.value).length < 20)){
		alert("이름은 2~20글자 까지 입니다.");
		document.regFrm.name.focus();
		return false;
	}
	
	if(document.regFrm.email.value == ""){
		alert("이메일 확인하세요");
		document.regFrm.email.focus();
		return false;
	}
	
	if(!((document.regFrm.email.value).includes('@')) || !((document.regFrm.email.value).includes('.'))){
		alert("이메일 형식이 올바르지 않습니다.");
		document.regFrm.email.focus();
		return false;
	}
	document.regFrm.submit();
}


