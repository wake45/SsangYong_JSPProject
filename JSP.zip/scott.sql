create table proMember(
  id varchar(20) primary key,
  pwd varchar(20),
  name varchar(20),
  email varchar(30));
  
create table Proboard(
    n int primary key,
    title varchar(50),
    userid varchar(20),
    hiredate varchar(20),
    readcount int,
    content varchar(2048),
    available int);

create table boardcomment(
  rown number,
  n number,
  comm varchar(1000),
  userid varchar(20),
  hiredate varchar(20)
);

create table WordDB(
  n number,
  word varchar(20),
  explain varchar(1000)
)

create table resultDB(
  id varchar(20),
  num number 
)

create table boardfile(
  n number,
  fileName varchar(200),
  fileRealName varchar(200)
)
==========현재게임==============
create SEQUENCE boardser;
-- 유저 랭킹
create table user_rank(
    id varchar(20) primary key,
    score number(30) DEFAULT 0,
    miss number(30) DEFAULT 0,
    timer varchar(100) DEFAULT '0');
    
-- 게임 게시판 db
  create table gameBoard(
    num number(20),
    writer varchar(100),
    subject varchar(200),
    content varchar(500),
    passwd varchar(20),
    boardid varchar(50),
    reg_date date,
    readcount number(20),
    ip varchar(50),
    ref number(20),
    re_step number(20),
    re_level number(20),
    filename varchar(200),
    filesize number(20));
========================
==========진혁게임===========
--게임에 필요한 아이디, 점수
CREATE TABLE ShootingGameRank(
id varchar(200),
score number(38)
);
create table bbs(
bbsID number(30) primary key,
bbsTitle varchar(50),
userID varchar(20),
bbsDate varchar(200),
bbsContent varchar(2048),
BBSAVAILABLE number(30));
===========================
=========지유게임============
create SEQUENCE boardser1;
CREATE TABLE PROBOARD (	
  NUM NUMBER(38,0) primary key, 
  BOARDID VARCHAR2(1) DEFAULT '1', 
  WRITER VARCHAR2(30) NOT NULL, 
  EMAIL VARCHAR2(30), 
  SUBJECT VARCHAR2(50) NOT NULL, 
  PASSWD VARCHAR2(12) NOT NULL, 
  REG_DATE DATE NOT NULL, 
  READCOUNT NUMBER(38,0) DEFAULT 0, 
  REF NUMBER(38,0) NOT NULL, 
  RE_STEP NUMBER(38,0) NOT NULL, 
  RE_LEVEL NUMBER(38,0) NOT NULL, 
  CONTENT VARCHAR2(3000) NOT NULL, 
  FILENAME VARCHAR2(20), 
  FILESIZE VARCHAR2(20), 
  IP VARCHAR2(20)
   );


CREATE TABLE PRORANK (	
  NO NUMBER(8,0) primary key, 
  LV NUMBER(20,0) not null,
  TIME NUMBER(20,0) not null,
  TOTALPOINT NUMBER(20,0) not null,
  ID VARCHAR2(20) not null
  );
===============================
insert into wordDB(word,explain,n) values('거두절미','앞뒤로 길게 이야기하지 않고 본론으로 들어간다.',1);
insert into wordDB(word,explain,n) values('금상첨화','비단 위의 꽃수. 더할 나위 없이 좋은것',2);
insert into wordDB(word,explain,n) values('목불인견','딱한 모양을 차마 눈뜨고 볼수없음',3);
insert into wordDB(word,explain,n) values('역지사지','처지를 바꾸어 생각함. 상대방의 처지에서 생각해봄',4);
insert into wordDB(word,explain,n) values('일망타진','한 사건에 관련 있는 자를 다 잡는 것',5);
insert into wordDB(word,explain,n) values('풍전등화','매우 위급한 경우에 놓여있음을 가리키는 말',6);
insert into wordDB(word,explain,n) values('자업자득','자기가 저지른 일의 과오를 자기자신이 받음',7);
insert into wordDB(word,explain,n) values('아비귀환','많은사람이 지옥같은 고통을 못이겨 구원을 부르짖는 측은한 소리',8);
insert into wordDB(word,explain,n) values('백골난망','죽어도 잊지 못할 큰 은혜를 입었다는 말',9);
insert into wordDB(word,explain,n) values('난공불락','공격하기 어렵고 빼앗기 어렵다',10);