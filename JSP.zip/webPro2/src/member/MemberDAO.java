package member;

import java.sql.*;
import java.util.*;

public class MemberDAO {
	private final String JDBC_Driver = "oracle.jdbc.driver.OracleDriver";
	private final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private final String USER = "SCOTT";
	private final String PASS = "6896";

	public MemberDAO(){
		try {
			Class.forName(JDBC_Driver);
		}
		catch(Exception e) {
			System.out.println("ERRPR : JDBC ����̹� �ε� ����");
		}
	}
	public boolean insertMember(MemberDTO bean){
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean flag = false;

		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			String strQuery = "insert into tblMember values(?,?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(strQuery);

			pstmt.setString(1, bean.getId());
			pstmt.setString(2, bean.getPwd());
			pstmt.setString(3, bean.getName());
			pstmt.setString(4, bean.getGender());
			pstmt.setString(5, bean.getBirthday());
			pstmt.setString(6, bean.getEmail());
			pstmt.setString(7, bean.getZipcode());
			pstmt.setString(8, bean.getAddress());
//			String[] hobby = bean.getHobby();
//
//			char hb[] = {'0','0','0','0','0'};
//			String lists[] = {"���ͳ�","����","����","��ȭ","�"};
//			//list[] ������ Ȯ���Ͽ� ������ 1�� �ִ´�
//
//			for(int i = 0; i<hobby.length; i++) {
//				for(int j = 0; j<lists.length; j++) {
//					if(hobby[i].equals(lists[j])) {
//						hb[j]='1';
//					}
//				}
//			}

			pstmt.setString(9, bean.getHob());
			pstmt.setString(10, bean.getJob());
			if(pstmt.executeUpdate()==1) {
				flag = true;
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
				Util.close(con, pstmt);
		}
		return flag;
	}
	
	public boolean checkId(String id) {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		boolean flag = false;
		try {
			con = DriverManager.getConnection(JDBC_URL, USER, PASS);
			sql = "select id from tblmember where id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			flag = pstmt.executeQuery().next();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			Util.close(con, pstmt);
		}
		return flag;
	}
	
	public Vector<ZipcodeBean> zipcodeRead(String area3) {
		Connection con = null;
		PreparedStatement pstmt= null;
		ResultSet rs = null;
		String sql = null;
		Vector<ZipcodeBean> vlist = new Vector<ZipcodeBean>();
		try {
			con = DriverManager.getConnection(JDBC_URL, USER, PASS);
			sql = "select * from tblZipcode where area3 like?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%" + area3 + "%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ZipcodeBean bean = new ZipcodeBean();
				bean.setZipcode(rs.getString(1));
				bean.setArea1(rs.getString(2));
				bean.setArea2(rs.getString(3));
				bean.setArea3(rs.getString(4));
				vlist.addElement(bean);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			Util.close(con, pstmt, rs);
		}
		return vlist;
	}
	
	public boolean loginMember(String id, String pwd) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		boolean flag = false;
		try {
			con = DriverManager.getConnection(JDBC_URL, USER, PASS);
			sql = "select id from tblMember where id = ? and pwd = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			rs = pstmt.executeQuery();
			flag = rs.next();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			Util.close(con, pstmt, rs);
		}
		return flag;
	}
	
	public boolean updateMember(MemberDTO bean){
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean flag = false;
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			String strQuery = "update tblMember set PWD = ?,NAME=?,GENDER=?,BIRTHDAY=?,EMAIL=?,ZIPCODE=?,ADDRESS=?,HOBBY=?,JOB=? where ID = ?";
			pstmt = con.prepareStatement(strQuery);
			pstmt.setString(1, bean.getPwd());
			pstmt.setString(2, bean.getName());
			pstmt.setString(3, bean.getGender());
			pstmt.setString(4, bean.getBirthday());
			pstmt.setString(5, bean.getEmail());
			pstmt.setString(6, bean.getZipcode());
			pstmt.setString(7, bean.getAddress());
//			String[] hobby = bean.getHobby();
//
//			char hb[] = {'0','0','0','0','0'};
//			String lists[] = {"���ͳ�","����","����","��ȭ","�"};
//			//list[] ������ Ȯ���Ͽ� ������ 1�� �ִ´�
//
//			for(int i = 0; i<hobby.length; i++) {
//				for(int j = 0; j<lists.length; j++) {
//					if(hobby[i].equals(lists[j])) {
//						hb[j]='1';
//					}
//				}
//			}

			pstmt.setString(8, bean.getHob());
			pstmt.setString(9, bean.getJob());
			pstmt.setString(10, bean.getId());
			if(pstmt.executeUpdate()==1) {
				flag = true;
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
				Util.close(con, pstmt);
		}
		return flag;
	}
	
	public MemberDTO getMember(String id) {
		Connection con = null;
		PreparedStatement pstmt= null;
		ResultSet rs = null;
		String sql = null;
		MemberDTO bean = null;
		try {
			con = DriverManager.getConnection(JDBC_URL, USER, PASS);
			sql = "select * from tblMember where id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				bean = new MemberDTO();
				bean.setId(rs.getString("id"));
				bean.setPwd(rs.getString("pwd"));
				bean.setName(rs.getString("name"));
				bean.setGender(rs.getString("gender"));
				bean.setBirthday(rs.getString("birthday"));
				bean.setEmail(rs.getString("email"));
				bean.setZipcode(rs.getString("zipcode"));
				bean.setAddress(rs.getString("address"));
//				String hobby[] = new String[5];
//				
//				String h = rs.getString("hobby");
//				
//				for(int i=0; i<hobby.length; i++) {
//					hobby[i] = h.substring(i, i+1);
//				}
				bean.setHob(rs.getString("hobby"));
				bean.setJob(rs.getString("job"));
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			Util.close(con, pstmt, rs);
		}
		return bean;
	}
	
	public boolean deleteMember(String id, String pwd){
		Connection con = null;
		PreparedStatement pstmt = null;
		boolean flag = false;

		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			String strQuery = "delete from tblmember where id = ? and pwd = ?";
			pstmt = con.prepareStatement(strQuery);

			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			if(pstmt.executeUpdate()==1) {
				flag = true;
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		finally {
				Util.close(con, pstmt);
		}
		return flag;
	}
	
	public List<MemberDTO> memberList() {
		Connection con = null;
		PreparedStatement pstmt= null;
		ResultSet rs = null;
		String sql = null;
		List<MemberDTO> li = new ArrayList<MemberDTO>();
		try {
			con = DriverManager.getConnection(JDBC_URL, USER, PASS);
			sql = "select * from tblmember";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				MemberDTO bean = new MemberDTO();
				bean.setId(rs.getString("id"));
				bean.setPwd(rs.getString("pwd"));
				bean.setName(rs.getString("name"));
				bean.setGender(rs.getString("gender"));
				bean.setBirthday(rs.getString("birthday"));
				bean.setEmail(rs.getString("email"));
				bean.setZipcode(rs.getString("zipcode"));
				bean.setAddress(rs.getString("address"));
				bean.setHob(rs.getString("hobby"));
				bean.setJob(rs.getString("job"));
				li.add(bean);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			Util.close(con, pstmt, rs);
		}
		return li;
	}
}