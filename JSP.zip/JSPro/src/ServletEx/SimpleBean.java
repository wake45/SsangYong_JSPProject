package ServletEx;

public class SimpleBean {
	private String message;
		
	@Override
	public String toString() {
		return "SimpleBean [message=" + message + "]";
	}

	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
}
