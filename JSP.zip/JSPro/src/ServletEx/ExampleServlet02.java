package ServletEx;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

@WebServlet("/ch03/exampleServlet02")
public class ExampleServlet02 extends HttpServlet{
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init ȣ��");
	}
	@Override
	public void destroy(){
		System.out.println("destroy ȣ��");
	}
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		System.out.println("service ȣ��");
	}
}
