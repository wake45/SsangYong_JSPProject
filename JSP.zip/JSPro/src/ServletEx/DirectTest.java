package ServletEx;

import java.sql.*;

public class DirectTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection con;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","scott","6896");
			System.out.println("Success");
		}
		catch(SQLException ex) { System.out.println("SQLException" + ex);}
		catch(Exception ex) { System.out.println("Exception" + ex); }
	}

}
