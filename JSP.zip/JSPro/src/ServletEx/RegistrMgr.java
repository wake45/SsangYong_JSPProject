package ServletEx;

import java.sql.*;
import java.util.*;

public class RegistrMgr {
	private final String JDBC_DRIVER = "oracle.jdbc.driver.OracleDriver";
	private final String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private final String USER = "scott";
	private final String PASS = "6896";
	
	public RegistrMgr() {
		try {
			Class.forName(JDBC_DRIVER);
			
		}catch(Exception e) {
			System.out.println("Error : JDBC ����̹� �ε� ���� ");
		}
	}
	
	public Vector<RegisterBean> getRegisterList(){
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		Vector<RegisterBean> vlist = new Vector<RegisterBean>();
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			String Query = "select * from emp";
			stmt = con.createStatement();
			rs = stmt.executeQuery(Query);
			while(rs.next()) {
				RegisterBean regBean = new RegisterBean();
				regBean.setEmpno(rs.getInt("empno"));
				regBean.setEname(rs.getString("ename"));
				regBean.setJob(rs.getString("job"));
				regBean.setMgr(rs.getInt("mgr"));
				regBean.setHiredate(rs.getString("hiredate"));
				regBean.setSal(rs.getInt("sal"));
				regBean.setComm(rs.getInt("comm"));
				regBean.setDeptno(rs.getInt("deptno"));
				vlist.add(regBean);
			}
		}catch(Exception ex) {
			System.out.println("Exception" + ex);
		}finally {
			if(rs!=null) try { rs.close(); } catch(SQLException e) {}
			if(stmt!=null) try { stmt.close(); } catch(SQLException e) {}
			if(con!=null) try { con.close(); } catch(SQLException e) {}
		}
		return vlist;
	}
	
	public boolean loginregister(String id,String pwd) {
		
		boolean ok = false;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
	
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			String Query = "select * from member where memberId = ? and password = ?";
			pstmt = con.prepareStatement(Query);
			pstmt.setString(1, id);
			pstmt.setString(2, pwd);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				ok=true;
			}
		}catch(Exception ex) {
			System.out.println("Exception" + ex);
		}finally {
			if(rs!=null) try { rs.close(); } catch(SQLException e) {}
			if(pstmt!=null) try { pstmt.close(); } catch(SQLException e) {}
			if(con!=null) try { con.close(); } catch(SQLException e) {}
		}
		
		return ok;
	}
}
