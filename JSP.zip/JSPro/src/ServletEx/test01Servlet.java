package ServletEx;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CH01/test01Servlet")
public class test01Servlet extends HttpServlet{
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		String itemcode = request.getParameter("itemcode");
		String name = request.getParameter("name");
		String specification = request.getParameter("specification");
		String qty = request.getParameter("qty");
		String price = request.getParameter("price");
		
		HttpSession session = request.getSession();
		session.setAttribute("itemcodeKey", itemcode);
		session.setAttribute("nameKey", name);
		session.setAttribute("specificationKey", specification);
		session.setAttribute("qtyKey", qty);
		session.setAttribute("priceKey", price);
		
		response.sendRedirect("/JSPro/test/test3/Pro2/form.jsp");
	}
}
