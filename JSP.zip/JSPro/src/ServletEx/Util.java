package ServletEx;

import java.sql.*;

public class Util {
	public static void close(Connection con, PreparedStatement stmt) {
		try {
			con.close();
			stmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void close(Connection con, Statement stmt) {
		try {
			con.close();
			stmt.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void close(Connection con, Statement stmt , ResultSet rs) {
		try {
			con.close();
			stmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void close(Connection con, PreparedStatement stmt  , ResultSet rs) {
		try {
			con.close();
			stmt.close();
			rs.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}
