package ServletEx;

import java.io.*;
import java.sql.*;
import java.util.Vector;

import javax.servlet.http.*;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

public class BoardMgr {
	private static final String SAVEFOLDER = "C:\\Temp\\fileUpload";
	private static final String ENCTYPE = "EUC-KR";
	private static int MAXSIZE = 5*1024*1024;
	private String DRIVER = "oracle.jdbc.driver.OracleDriver";
	private String JDBC_URL = "jdbc:oracle:thin:@localhost:1521:xe";
	private String USER = "scott";
	private String PASS = "6896";
	
	public BoardMgr(){
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			System.out.println("Error : JDBC ����̹� �ε�����");
		}
	}
	
	public void insertBoard(HttpServletRequest req) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		MultipartRequest multi = null;
		int filesize = 0;
		String filename = null;
		
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			sql = "select nvl(max(num),0) from tblBoard"; //?
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			int ref = 0;
			int num = 0;
			//���� ����?
			if(rs.next()) {
				num = rs.getInt(1)+1;
				ref = num;
			}
			File file = new File(SAVEFOLDER);
			
			if(!file.exists())
				file.mkdir();

			multi = new MultipartRequest(req,SAVEFOLDER,MAXSIZE,ENCTYPE,new DefaultFileRenamePolicy());
			//DefaultFileRenamePolicy�� ���� ���ϸ��� �ִ����� �˻��ϰ� ���� ��쿡�� ���ϸ��ڿ� ���ڸ� �����ش�. 
			if(multi.getFilesystemName("filename") != null) { //form���� fileŸ������ ���� name
				filename = multi.getFilesystemName("filename");
				filesize = (int)multi.getFile("filename").length();
			}
			
			String content = multi.getParameter("content");
			/*
			if(multi.getParameter("contentType").equalsIgnoreCase("TEXT")) {
				content = UtilMgr.replace(content,"<","&lt;");
			}*/
			sql = "insert into tblBoard(num,name,content,subject,ref,pos," + "depth,regdate,pass,count,ip,filename,filesize)";
			sql += "values(?,?,?,?,?,0,0,sysdate,?,0,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, num); 
			pstmt.setString(2, multi.getParameter("name")); 
			pstmt.setString(3, content);
			pstmt.setString(4, multi.getParameter("subject"));
			pstmt.setInt(5,ref); 
			pstmt.setString(6, multi.getParameter("pass"));
			pstmt.setString(7, multi.getParameter("ip"));
			pstmt.setString(8, filename);
			pstmt.setInt(9,filesize);
			pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt);
		}
	}

	public void post1000() {
		Connection con = null;
		PreparedStatement pstmt = null;
		String sql = null;
		int index = 3;
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			
			for(int i = 0 ; i < 100 ; i++) {
				sql = "insert into tblBoard(num,name,content,subject,ref," + "pos,depth,regdate,pass,count,ip,filename,filesize)";
				sql += "values("+ (++index) +",'aaa','bbb','ccc', " + index + ", 0, 0,sysdate,'111',0,'127.0.0.1',null,0)";
				pstmt = con.prepareStatement(sql);
				System.out.println(sql);
				pstmt.executeUpdate();
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt);
		}
	}
	
	public Vector<BoardBean> getBoardList(String keyField,String keyWord,int start,int end) {
		//System.out.println(start + "." + (start+end));
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		Vector<BoardBean> vlist = new Vector<BoardBean>();
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			if(keyWord.equals("null") || keyWord.equals("")) {
				sql = "select * from( select rownum rnum, a.* from (select * from tblBoard order by ref desc,pos)a) where rnum between ? and ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setInt(1,start);
				pstmt.setInt(2,(start+end));
			}else {
				sql = "select * from( select rownum rnum, a.* from (select * from tblBoard order by ref desc,pos)a) where" + keyField +" like ? order by ref des, pos limit ? , ?";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1,  "%" + keyWord + "%");
				pstmt.setInt(2, start);
				pstmt.setInt(3, end);
			}
			rs = pstmt.executeQuery();
			while(rs.next()) {
				BoardBean bean = new BoardBean();
				bean.setNum(rs.getInt("num"));
				bean.setName(rs.getString("name"));
				bean.setSubject(rs.getString("subject"));
				bean.setPos(rs.getInt("pos"));
				bean.setRef(rs.getInt("ref"));
				bean.setDepth(rs.getInt("depth"));
				bean.setRegdate(rs.getString("regdate"));
				bean.setCount(rs.getInt("count"));
				vlist.add(bean);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt,rs);
		}
		return vlist;
	}
	
	public int getTotalCount(String keyField, String keyWord) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		int totalCount = 0;
		try {
			con = DriverManager.getConnection(JDBC_URL,USER,PASS);
			if(keyWord.equals("null")|| keyWord.equals("")) {
				sql = "select count(num) from tblBoard";
				pstmt = con.prepareStatement(sql);
			}else {
				sql = "select count(num) from tblBoard where" + keyField + " like ? ";
				pstmt = con.prepareStatement(sql);
				pstmt.setString(1, "%" + keyWord + "%");
			}
				rs = pstmt.executeQuery();
				if(rs.next()) {
					totalCount = rs.getInt(1);
				}			
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt ,rs);
		}
		return totalCount;
	}
	
	public static void main(String args[]) {
		new BoardMgr().post1000();
		System.out.println("success");
	}
}
