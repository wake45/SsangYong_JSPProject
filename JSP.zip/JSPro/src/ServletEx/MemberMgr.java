package ServletEx;

import java.sql.*;
import java.util.Vector;

public class MemberMgr {
	private String driver = "oracle.jdbc.driver.OracleDriver";
	private String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private String user = "scott";
	private String pass = "6896";
	
	public boolean insertMember(tdlMemberBean bean) throws SQLException, ClassNotFoundException {
		
		boolean flag = false;
		Connection con = null;
		PreparedStatement stmt = null;
		
		Class.forName(driver);
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.prepareStatement("insert into tdlmember values(? ,? ,? ,? ,? ,? ,? ,? ,? ,?)");
			stmt.setString(1, bean.getId());
			stmt.setString(2, bean.getPwd());
			stmt.setString(3, bean.getName());
			stmt.setString(4, bean.getGender());
			stmt.setString(5, bean.getBirthday());
			stmt.setString(6, bean.getEmail());
			stmt.setString(7, bean.getZipcode());
			stmt.setString(8, bean.getAddress());
			
			
			String hobby[] = bean.getHobby();
			char hb[] = { '0', '0', '0', '0', '0' };
			String lists[] = {"Internet" , "travel" , "game" , "movie" , "exercise"};
			
			for(int i = 0 ; i < hobby.length ; i++) {
				for(int j = 0 ; j < lists.length ; j++) {
					if(hobby[i].equals(lists[j])) {
						hb[j] = '1';
					}
				}
			}
			
			stmt.setString(9, new String(hb));
			stmt.setString(10, bean.getJob());
			if(stmt.executeUpdate() == 1) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		
		System.out.println(flag);
		return flag;
	}
	
	public boolean checkId(String id) throws ClassNotFoundException, SQLException {
		
		boolean flag = false;
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		
		Class.forName(driver);
		
		try {
			con = DriverManager.getConnection(url,user,pass);
			stmt = con.createStatement();
			rs = stmt.executeQuery("select id from tdlMember where id = '" + id + "'");
		
			if(rs.next()) {
				flag = true;
			}
		}finally{
			try {
				Util.close(con,stmt);
			}catch ( Exception e) {}
		}
		return flag;
	}
	
	public Vector<ZipcodeBean> zipcodeRead(String area3) throws ClassNotFoundException{
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = null;
		
		Class.forName(driver);
		
		Vector<ZipcodeBean> vlist = new Vector<ZipcodeBean>();
		try {
			con = DriverManager.getConnection(url,user,pass);
			sql = "select * from tblZipcode where area3 like ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, "%"+area3+"%");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				ZipcodeBean bean = new ZipcodeBean();
				bean.setZipcode(rs.getString(1));
				bean.setArea1(rs.getString(2));
				bean.setArea2(rs.getString(3));
				bean.setArea3(rs.getString(4));
				vlist.addElement(bean);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			Util.close(con, pstmt, rs);
		}
		return vlist;
	}
}

