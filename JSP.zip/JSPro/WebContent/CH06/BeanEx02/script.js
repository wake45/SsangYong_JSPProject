function inputCheck(){
		
	if(document.regForm.id.value==""){
		alert("input id");
		document.regForm.id.focus();
		return;
	}
	if(document.regForm.pwd.value==""){
		alert("input pwd");
		document.regForm.pwd.focus();
		return;
	}
	
	if(document.regForm.repwd.value==""){
		alert("input pwdCheck");
		document.regForm.repwd.focus();
		return;
	}
	
	if(document.regForm.name.value==""){
		alert("input name");
		document.regForm.name.focus();
		return;
	}
	
	if(document.regForm.birthday.value==""){
		alert("input birthday");
		document.regForm.birthday.focus();
		return;
	}
	
	if(document.regForm.email.value==""){
		alert("input email");
		document.regForm.email.focus();
		return;
	}
	
	if(document.regForm.pwd.value != document.regForm.repwd.value){
		alert("비밀번호가 일치하지 않습니다.");
		document.regForm.repwd.focus();
		return;
	}
	
	document.regForm.submit();
	
}